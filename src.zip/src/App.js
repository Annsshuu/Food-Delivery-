import React from 'react';
import FoodDeliveryApp from './components/FoodDeliveryApp';
import './index.css';

function App() {
  return <FoodDeliveryApp />;
}

export default App;
